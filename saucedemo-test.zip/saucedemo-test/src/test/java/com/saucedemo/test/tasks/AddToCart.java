package com.saucedemo.test.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static com.saucedemo.test.ui.ProductsPage.*;

public class AddToCart implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Click.on(ADD_FIRST_PRODUCT_TO_CART),
            Click.on(ADD_SECOND_PRODUCT_TO_CART)
        );
    }

    public static AddToCart twoProducts() {
        return instrumented(AddToCart.class);
    }
}

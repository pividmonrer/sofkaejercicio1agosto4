package com.saucedemo.test.runners;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.saucedemo.test.tasks.*;

@RunWith(SerenityRunner.class)
public class SaucedemoTest {

    @Managed
    WebDriver driver;
    Actor user = Actor.named("User");

    @Before
    public void setUp() {
        WebDriverManager.chromedriver().driverVersion("127.0.6533.89").setup();
        driver = new ChromeDriver();
        user.can(BrowseTheWeb.with(driver));
    }


    @Test
    public void should_complete_purchase() {
        user.attemptsTo(
            Login.onSauceDemo(),
            AddToCart.twoProducts(),
            ViewCart.items(),
            Checkout.process()
        );
    }
}

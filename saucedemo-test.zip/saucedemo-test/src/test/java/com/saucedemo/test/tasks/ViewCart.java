package com.saucedemo.test.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static com.saucedemo.test.ui.ProductsPage.CART_BUTTON;

public class ViewCart implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Click.on(CART_BUTTON)
        );
    }

    public static ViewCart items() {
        return instrumented(ViewCart.class);
    }
}

package com.saucedemo.test.ui;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class ProductsPage {
    public static final Target ADD_FIRST_PRODUCT_TO_CART = Target.the("add first product to cart").located(By.id("add-to-cart-sauce-labs-backpack"));
    public static final Target ADD_SECOND_PRODUCT_TO_CART = Target.the("add second product to cart").located(By.id("add-to-cart-sauce-labs-bike-light"));
    public static final Target CART_BUTTON = Target.the("cart button").located(By.className("shopping_cart_link"));
}

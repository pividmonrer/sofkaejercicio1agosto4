package com.saucedemo.test.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actions.Click;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static com.saucedemo.test.ui.LoginPage.*;

public class Login implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Open.url("https://www.saucedemo.com/"),
            Enter.theValue("standard_user").into(USERNAME_FIELD),
            Enter.theValue("secret_sauce").into(PASSWORD_FIELD),
            Click.on(LOGIN_BUTTON)
        );
    }

    public static Login onSauceDemo() {
        return instrumented(Login.class);
    }
}

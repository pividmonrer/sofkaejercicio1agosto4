package com.saucedemo.test.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Click;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static com.saucedemo.test.ui.CartPage.*;
import static com.saucedemo.test.ui.CheckoutPage.*;

public class Checkout implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Click.on(CHECKOUT_BUTTON),
            Enter.theValue("David").into(FIRST_NAME_FIELD),
            Enter.theValue("Paez").into(LAST_NAME_FIELD),
            Enter.theValue("1723112643").into(ZIP_CODE_FIELD),
            Click.on(CONTINUE_BUTTON),
            Click.on(FINISH_BUTTON)
        );
    }

    public static Checkout process() {
        return instrumented(Checkout.class);
    }
}
